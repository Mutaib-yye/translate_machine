Tugas Kelompok 2 - Evaluasi Otomatis dan Analisis Error MT (EN-ID)
Nama : Mutaib Bin Mehraj Rather
NPM  : 250820701100010

1_Laporan/         Report (Word + PDF): method, BLEU-1..4 / chrF / chrF++ / TER, n-gram analysis, error analysis, limits of BLEU
2_Notebook/        MT_Evaluation_EN_ID.ipynb - the notebook as executed (outputs included)
3_Data_dan_Hasil/  FLORES-200 EN-ID data (2009 pairs) and results/ (scores, translations, sentence-level CSVs, figures)
4_Kode/            Python modules used by the notebook (src/), command-line runner, tests, requirements.txt

Repository: https://github.com/Mutaib-yye/translate_machine
Setup: 200 sentences (seed 42), MarianMT opus-mt-en-id and NLLB-200 distilled 600M, beam 4, Google Colab T4.

Use of AI assistance: An AI assistant (Claude, by Anthropic) was used while preparing this work, for writing the evaluation code and notebook, structuring the report and drafting parts of its text. The experiments were run by the author on Google Colab.
